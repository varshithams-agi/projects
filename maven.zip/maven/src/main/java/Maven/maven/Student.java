package Maven.maven;
import org.springframework.beans.factory.annotation.Autowired;
public class Student {
	@Autowired
	Address adrs;

	public Address getAdrs() {
		return adrs;
	}

	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	void displayadd() {
		adrs.display();
	}
	
}
