package Maven.maven;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
        MessagePass pass=(MessagePass)context.getBean("msgpass");
        pass.displaymsg();
        
        Student stud=(Student)context.getBean("stdadr");
        stud.displayadd();
        
        Employee e=(Employee)context.getBean("empsal");
        e.displayemp();
    }
}
