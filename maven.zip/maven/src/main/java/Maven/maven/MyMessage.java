package Maven.maven;
import org.springframework.stereotype.Component;

public class MyMessage {

	public MyMessage() {
		System.out.println("inside constructor");
		
	}
	void display() {
		System.out.println("inside method");
	}
	

}
