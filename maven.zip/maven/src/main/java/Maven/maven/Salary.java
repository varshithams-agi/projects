package Maven.maven;


public class Salary {
	float salary;
	int days=20;
	float daysal=1000;
	public Salary() {
		this.salary=days*daysal;
		System.out.println("Employee salary");
	}
	void display() {
		System.out.println("total salary"+this.salary);
}
}