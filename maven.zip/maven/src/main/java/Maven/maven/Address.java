package Maven.maven;
import org.springframework.stereotype.Component;

public class Address {

	public Address() {
		System.out.println("Address is Banglore");
		
	}
	void display() {
		System.out.println("Thank you");
	}

}
