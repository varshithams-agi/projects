package JdbcDemoSpring.jdbcdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext  context=new ClassPathXmlApplicationContext("config.xml");
    	 EmployeeOperations op=(EmployeeOperations)context.getBean("operationdemo");
    	 
    	 Employee e1=new Employee();
    	 e1.setEmail("abc@gmail.com");
    	 e1.setId("10");
    	 e1.setName("varsha");
    	 e1.setSalary("27000");
    	 
	int result=     op.insert(e1);
System.out.print(result);
    	
    	
    	
    	
    }
}
