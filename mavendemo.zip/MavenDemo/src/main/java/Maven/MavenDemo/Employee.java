package Maven.MavenDemo;

public class Employee {
	String name;
	int id;
	int salary;
	String address;
	public Employee(String name, int id, int salary, String address) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
		this.address = address;
	}
	void display() {
		System.out.println("Employee Name: "+name+"  Employee id: "+id+" Employee salary "+salary+" Address: "+address);
	}

}
