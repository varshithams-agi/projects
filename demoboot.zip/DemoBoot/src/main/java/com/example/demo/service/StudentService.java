package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Service

public class StudentService {
	@Autowired
	StudentRepository repository;
	
	public List<Student> getAllStudents(){
		return repository.findAll();
		
	}
	
	public void saveStudent(Student s) {
		repository.save(s);
		
	}
	public void deleteStudent(String e) {
		repository.deleteById(e);
	}

	public Optional<Student> getStudents(String id) {
		
		return repository.findById(id);
	}

	public void updateStudent(Student ee, String id) {
		repository.getById(id);
		repository.save(ee);
		
	}

}
